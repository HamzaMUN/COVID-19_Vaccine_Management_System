<!-- Start Footer -->
<footer class="footer">
    <div class="copyright">
      &copy; Copyright 2021 <strong><span>COVID-19 Vaccine Management System</span></strong>. All Rights Reserved.
    </div>
    <div class="credits">
      Designed by <a href="#">Hamza Ashraf (BS170400637)</a>
    </div>
</footer><!-- End Footer -->
