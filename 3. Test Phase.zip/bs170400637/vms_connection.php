<?php
$servername = "localhost";
$dbuser = "admin";
$dbpass = "1";
$dbname = "vms";
?>
